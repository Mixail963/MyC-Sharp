﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WH_4_8_2//Задание 2. Сложение матриц

{
    class Program
    {
        static void Main(string[] args)
        {
            
            int rows = 2;
            int columns = 3;

            
            int[,] matrixA = new int[rows, columns];//создайте одну матрицу.
            Random rnd = new Random();
            Console.WriteLine("Matrix A:");
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    matrixA[i, j] = rnd.Next(1, 10);
                    Console.Write(matrixA[i, j] + " ");
                }
                Console.WriteLine();
            }

            
            int[,] matrixB = new int[rows, columns];//создайте ещё одну матрицу.
            Console.WriteLine("Matrix B:");
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    matrixB[i, j] = rnd.Next(1, 10);
                    Console.Write(matrixB[i, j] + " ");
                }
                Console.WriteLine();
            }

           
            int[,] matrixSum = new int[rows, columns];//Сложите две матрицы. 
            Console.WriteLine("Matrix sum:");
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    matrixSum[i, j] = matrixA[i, j] + matrixB[i, j];
                    Console.Write(matrixSum[i, j] + " ");
                }
                Console.WriteLine();
            }
            Console.ReadKey(true);
        }
    }
}
