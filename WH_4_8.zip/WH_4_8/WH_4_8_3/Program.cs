﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WH_4_8_3//Задание 3. Игра «Жизнь» (выполните по желанию) 
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.CursorVisible = false;
            int width = Console.WindowWidth;
            int height = Console.WindowHeight;
            int m = width / 2;
            int n = height / 2;

            bool[,] bacteria = new bool[m, n];

            Random random = new Random();
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    bacteria[i, j] = random.Next(2) == 1;
                }
            }

            while (true)
            {
                Console.Clear();
                for (int i = 0; i < m; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        if (bacteria[i, j])
                        {
                            Console.Write("*");
                        }
                        else
                        {
                            Console.Write(" ");
                        }
                    }
                    Console.WriteLine();
                }

                bool[,] newBacteria = new bool[m, n];

                for (int i = 0; i < m; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        int liveNeighbors = 0;
                        for (int x = i - 1; x <= i + 1; x++)
                        {
                            for (int y = j - 1; y <= j + 1; y++)
                            {
                                if (x >= 0 && x < m && y >= 0 && y < n && !(x == i && y == j))
                                {
                                    if (bacteria[x, y])
                                    {
                                        liveNeighbors++;
                                    }
                                }
                            }
                        }

                        if (bacteria[i, j] && liveNeighbors >= 2 && liveNeighbors <= 3)
                        {
                            newBacteria[i, j] = true;
                        }
                        else if (!bacteria[i, j] && liveNeighbors == 3)
                        {
                            newBacteria[i, j] = true;
                        }
                        else
                        {
                            newBacteria[i, j] = false;
                        }
                    }
                }
                bacteria = newBacteria;
                System.Threading.Thread.Sleep(100);
            }

        }
    }
}
