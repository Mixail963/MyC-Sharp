﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WH_4_8//Задание 1. Случайная матрица
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of rows in the matrix: ");//пользователю предлагается ввести количество строк в будущей матрице.
            int rows = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the number of columns in the matrix: ");//ввести количество столбцов в будущей матрице.
            int columns = int.Parse(Console.ReadLine());

            int[,] matrix = new int[rows, columns];//нужно создать в памяти матрицу заданного размера.
            Random random = new Random();

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)
                {
                    matrix[i, j] = random.Next(0, 100);//Используя Random, заполнить матрицу случайными целыми числами.
                }
            }

            Console.WriteLine("Generated matrix: ");
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)//Для работы с матрицами используйте вложенные циклы.
                {
                    Console.Write(matrix[i, j] + " ");//Вывести полученную матрицу на экран. 
                }
                Console.WriteLine();
            }

            int sum = 0;
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < columns; j++)//Для работы с матрицами используйте вложенные циклы.
                {
                    sum += matrix[i, j];
                }
            }

            Console.WriteLine("The sum of all elements in the matrix is: " + sum);//Вывести сумму всех элементов этой матрицы на экран отдельной строкой.
            Console.ReadLine();
        }
    }

}