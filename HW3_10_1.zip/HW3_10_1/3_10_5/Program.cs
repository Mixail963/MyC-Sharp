﻿using System;

namespace _3_10_5  //Задание 5.Создать игру «Угадай число».
{


 class Program
 {


    static void Main(string[] args)
    {
        Console.Write("Enter the maximum number range: ");
        int range = Convert.ToInt32(Console.ReadLine());//Пользователь вводит максимальное целое число диапазона.
        Random random = new Random();
        int target = random.Next(range);

        while (true)
        {
            Console.Write("Enter your guess or press the Enter for Exit ");//Пользователь вводит свои предположения
            string guessString = Console.ReadLine();


            if (string.IsNullOrWhiteSpace(guessString))//Реализована возможность выхода из бесконечного цикла.
                {
                Console.WriteLine("The number is " + target);
                break;
            }


            int guess = Convert.ToInt32(guessString);

            if (guess < target)
            {
                Console.WriteLine("The target number is higher.");//число больше загаданного.
                }
            else if (guess > target)
            {
                Console.WriteLine("The target number is lower.");//число меньше загаданного, программа сообщает об этом пользователю
                }
            else
            {
                Console.WriteLine("You guessed the target number!");
                break;
            }
        }
    }

 } 

}
