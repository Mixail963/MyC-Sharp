﻿using System;

namespace _3_10_2  //Задание 2. Программа подсчёта суммы карт в игре «21»
{
    
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Hello! How many cards do you have? ");//спрашиваем у пользователя число карт имеющееся в руках
            int cardCount = Convert.ToInt32(Console.ReadLine());//инициализируем переменную и конвертируем в целочисленное число
            int sum = 0;

            for (int i = 1; i <= cardCount; i++) //Преобразуем это число в счётчик для цикла.
            {
                Console.Write("Enter the value of the card: "); //просим пользователя ввести номинал каждой карты
                string card = Console.ReadLine().ToUpper(); ///инициализируем переменную
                int cardValue = 0;//«вес» каждой карты складываем в общую переменную суммы

                switch (card)//используя оператор switch, «вес» каждой карты складываем в общую переменную суммы
                {
                    case "J":
                    case "Q":
                    case "K":
                    case "T":
                        cardValue = 10;
                        break;
                    default:
                        cardValue = Convert.ToInt32(card);
                        break;
                }

                sum = sum + cardValue;
            }

            Console.WriteLine("Sum of all cards: " + sum);//Программа выводит на экран информацию о сумме карт на руках у пользователя. 
            Console.ReadKey(true);
        }
    }
}
