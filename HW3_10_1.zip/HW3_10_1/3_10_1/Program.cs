﻿using System;

namespace _3_10_1   //Задание 1. Приложение по определению чётного или нечётного числа
{
    
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the Number: "); //просим пользователя ввести число.
            int num = int.Parse(Console.ReadLine()); //считываем и конвертируем в целочисленное число.

            if (num % 2 == 0) //задаем условие
            {
                Console.WriteLine($"The Number {num} - is Even."); //получаем результат если условие True.
            }
            else
            {
                Console.WriteLine($"The Number {num} - is odd."); //получаем результат если условие False.
            }
            Console.ReadKey(true);
        }
    }
}
