﻿using System;

namespace _3_10_3  //Задание 3. Проверка простого числа
{
    
    internal class Program
    {
        static void Main(string[] args)
        {
            bool isPrime = true;
            Console.Write("Enter the number: ");//просим пользователя ввести число
            int n = int.Parse(Console.ReadLine());//считываем и конвертируем в целочисленное число.

            int i = 2;

            while (i <= n - 1)
            {
                if (n % i == 0)
                {
                    isPrime = false;
                    break;
                }
                i++;
            }
            if (isPrime)
            {
                Console.WriteLine("The Number is Prime");
            }
            else
            {
                Console.WriteLine("The Number is not Prime");
            }
            Console.ReadKey(true);
        }
    }
}
