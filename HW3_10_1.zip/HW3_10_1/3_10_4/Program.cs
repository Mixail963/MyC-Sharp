﻿using System;

namespace _3_10_4  //Задание 4.Найти наименьший элемент в последовательности.

{
    internal class Program
    {
        static void Main(string[] args)
        {
            int minValue = int.MaxValue;

            Console.WriteLine("Enter sequence length: ");//Пользователь вводит длину последовательности
            int length = int.Parse(Console.ReadLine());

            for (int i = 0; i < length; i++)
            {
                Console.Write("Enter the number: ");//пользователь последовательно вводит целые числа
                int number = int.Parse(Console.ReadLine());

                if (number < minValue)//число сравнивается со значением переменной
                {
                    minValue = number;//обновляем значение переменной
                }
            }

            Console.WriteLine("Smallest number in sequence: " + minValue);

            Console.ReadKey(true);
        }
    }
}
